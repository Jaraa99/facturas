package com.example.member

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class MemberApplication

fun main(args: Array<String>) {
	runApplication<MemberApplication>(*args)
}
